<?php
session_start();
include '../config/koneksi.php';

// proteksi halaman
if(!isset($_SESSION['login']) || $_SESSION['login'] !== true){
    header("Location: ../login/HalamanLogin.php");
    exit;
}

// ambil data laporan
$query = mysqli_query($koneksi, "SELECT * FROM laporan ORDER BY id_laporan DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Pegawai - SarpraCare</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #F8FAFC; }
    </style>
</head>

<body class="min-h-screen flex flex-col">

    <nav class="bg-white border-b px-8 py-4 flex justify-between items-center sticky top-0 z-50">
        <div class="flex items-center gap-3">
            <div class="bg-blue-600 p-2 rounded-xl text-white">
                <i class="fas fa-user-shield"></i>
            </div>
            <div>
                <span class="text-lg font-bold text-gray-800 block">Sarpra<span class="text-blue-600">Admin</span></span>
                <span class="text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-bold uppercase" id="roleBadge">Unit Kerja</span>
            </div>
        </div>
        <div class="flex items-center gap-6">
            <div class="text-right">
                <p class="text-sm font-bold text-gray-800"><?= $_SESSION['nama_pegawai']; ?></p>
                <p class="text-[10px] text-gray-400 font-medium">NIP: <?= $_SESSION['nip']; ?></p>
            </div>
            <button onclick="logout()" class="w-10 h-10 rounded-full bg-red-50 text-red-500 flex items-center justify-center hover:bg-red-500 hover:text-white transition">
                <i class="fas fa-sign-out-alt"></i>
            </button>
        </div>
    </nav>

    <main class="max-w-7xl mx-auto w-full px-8 py-10">
        <div class="mb-10">
            <h1 class="text-2xl font-bold text-gray-800">Daftar Tugas Masuk</h1>
            <p class="text-gray-500">Kelola validasi laporan kerusakan aset di unit Anda.</p>
        </div>

        <div class="flex gap-4 mb-8 overflow-x-auto pb-2">
            <button class="px-6 py-2.5 bg-blue-600 text-white rounded-full text-sm font-bold shadow-lg shadow-blue-100">Semua Tugas</button>
            <button class="px-6 py-2.5 bg-white text-gray-500 border border-gray-100 rounded-full text-sm font-bold hover:bg-gray-50">Perlu Verifikasi</button>
            <button class="px-6 py-2.5 bg-white text-gray-500 border border-gray-100 rounded-full text-sm font-bold hover:bg-gray-50">Dalam Perbaikan</button>
        </div>

        <div class="bg-white rounded-[32px] shadow-sm border border-gray-100 overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-gray-50 text-[11px] uppercase font-bold text-gray-400 tracking-wider">
                    <tr>
                        <th class="p-6">Detail Laporan</th>
                        <th class="p-6">Lokasi Spesifik</th>
                        <th class="p-6">Prioritas</th>
                        <th class="p-6">Status Alur</th>
                        <th class="p-6">Tindakan</th>
                    </tr>
                </thead>
                <tbody class="text-sm divide-y divide-gray-50">
<?php while($row = mysqli_fetch_assoc($query)): ?>
<tr class="hover:bg-gray-50 transition">
    <td class="p-6">
        <span class="text-[10px] font-bold text-blue-600 block mb-1">
            #<?= $row['id_laporan']; ?>
        </span>
        <p class="font-bold text-gray-800"><?= $row['deskripsi']; ?></p>
        <p class="text-xs text-gray-400">Oleh: <?= $row['nim']; ?></p>
    </td>

    <td class="p-6">
        <p class="font-medium text-gray-700"><?= $row['lokasi_gedung']; ?></p>
        <p class="text-xs text-gray-500 italic"><?= $row['lokasi_ruang']; ?></p>
    </td>

    <td class="p-6">
        <?php if($row['jenis_kerusakan'] == 'URGENT'): ?>
            <span class="px-3 py-1 bg-red-100 text-red-600 rounded-full text-[10px] font-bold">URGENT</span>
        <?php else: ?>
            <span class="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-[10px] font-bold">NORMAL</span>
        <?php endif; ?>
    </td>

    <td class="p-6">
        <span class="text-[10px] font-bold text-orange-500">
            <?= $row['status_perbaikan']; ?>
        </span>
    </td>

    <td class="p-6">
        <button class="bg-blue-50 text-blue-700 px-5 py-2 rounded-xl text-xs font-bold">
            <?= $row['catatan_teknisi']; ?>
        </button>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
            </table>
        </div>
    </main>

    <script>
        // Simulasi penyesuaian role berdasarkan login sebelumnya
        window.onload = function() {
            const role = localStorage.getItem('role');
            const badge = document.getElementById('roleBadge');
            if(role === 'staff') badge.innerText = "Unit Kerja / Kasubbag";
        }

        function logout() {
            if(confirm('Keluar dari panel pegawai?')) {
                localStorage.clear();
                window.location.href = '../login/halamanLogin.php';
            }
        }
    </script>
</body>
</html>