<?php
session_start();
include '../config/Koneksi.php'; 


if(!isset($_SESSION['login']) || $_SESSION['role'] != 'stafwadir'){
    header("Location: ../login/HalamanLogin.php");
    exit;
}


if(!isset($_GET['id'])) {
    header("Location: HalamanDashbordStaf.php");
    exit;
}

$id = mysqli_real_escape_string($koneksi, $_GET['id']);
$query = mysqli_query($koneksi, "SELECT * FROM laporan WHERE id_laporan = '$id'");
$data = mysqli_fetch_assoc($query);


if(isset($_POST['update_status'])) {
    $status = $_POST['status_perbaikan'];
    $catatan = mysqli_real_escape_string($koneksi, $_POST['catatan_teknisi']);
    

    $foto_name = $data['foto_sesudah'] ?? ''; 
    if(isset($_FILES['foto_sesudah']) && $_FILES['foto_sesudah']['name'] != "") {
        $ekstensi = pathinfo($_FILES['foto_sesudah']['name'], PATHINFO_EXTENSION);
        // Penamaan file: after_ID_Waktu.ekstensi
        $foto_name = "after_" . $id . "_" . time() . "." . $ekstensi;
        $target_dir = "../assets/laporan/";
        
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        move_uploaded_file($_FILES['foto_sesudah']['tmp_name'], $target_dir . $foto_name);
    }

    $update = mysqli_query($koneksi, "UPDATE laporan SET 
                status_perbaikan = '$status', 
                catatan_teknisi = '$catatan',
                foto_sesudah = '$foto_name' 
                WHERE id_laporan = '$id'");

    if($update) {
        echo "<script>alert('Pembaruan berhasil!'); window.location='HalamanDashbordStaf.php';</script>";
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Eksekusi - SarpraCare</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #F8FAFC; }
        .emerald-gradient { background: linear-gradient(135deg, #064e3b 0%, #065f46 100%); }
    </style>
</head>
<body class="p-6 md:p-12">
    <div class="max-w-2xl mx-auto">
        <a href="HalamanDashbordStaf.php" class="inline-flex items-center gap-2 text-green-700 hover:text-green-900 mb-8 font-bold transition">
            <i class="fas fa-chevron-left text-sm"></i> Kembali
        </a>

        <div class="bg-white rounded-[40px] shadow-2xl border border-gray-100 overflow-hidden">
            <div class="emerald-gradient p-10 text-white text-center">
                <h2 class="text-2xl font-bold">Update Pengerjaan</h2>
                <p class="text-green-200 text-xs mt-1">ID LAPORAN: #<?= $data['id_laporan']; ?></p>
            </div>

            <form action="" method="POST" enctype="multipart/form-data" class="p-10 space-y-8">
                <div class="grid grid-cols-2 gap-6 text-center">
                    <div class="p-5 bg-gray-50 rounded-3xl border">
                        <p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Objek</p>
                        <p class="font-bold text-gray-800"><?= $data['jenis_kerusakan']; ?></p>
                    </div>
                    <div class="p-5 bg-gray-50 rounded-3xl border">
                        <p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Lantai</p>
                        <p class="font-bold text-gray-800"><?= $data['Lantai']; ?></p>
                    </div>
                </div>

                <div>
                    <label class="block text-[10px] font-bold text-gray-400 uppercase mb-3 ml-2">Status Pengerjaan</label>
                    <select name="status_perbaikan" class="w-full p-4 bg-gray-50 border rounded-2xl outline-none focus:border-green-500 font-bold text-gray-700">
                        <option value="Proses Perbaikan" <?= ($data['status_perbaikan'] == 'Proses Perbaikan') ? 'selected' : ''; ?>>🛠️ SEDANG DIPROSES</option>
                        <option value="Selesai" <?= ($data['status_perbaikan'] == 'Selesai') ? 'selected' : ''; ?>>✅ SELESAI</option>
                    </select>
                </div>

                <div>
                    <label class="block text-[10px] font-bold text-gray-400 uppercase mb-3 ml-2 text-center">Bukti Foto Sesudah</label>
                    <input type="file" name="foto_sesudah" accept="image/*" class="w-full p-4 bg-gray-50 border border-dashed rounded-2xl cursor-pointer hover:bg-gray-100 transition">
                </div>

                <div>
                    <label class="block text-[10px] font-bold text-gray-400 uppercase mb-3 ml-2">Catatan Teknisi / Hasil</label>
                    <textarea name="catatan_teknisi" rows="3" class="w-full p-5 bg-gray-50 border rounded-3xl outline-none focus:border-green-500" placeholder="Jelaskan apa saja yang sudah diperbaiki..."><?= $data['catatan_teknisi']; ?></textarea>
                </div>

                <button type="submit" name="update_status" class="w-full emerald-gradient text-white font-bold py-5 rounded-[24px] hover:opacity-90 transition shadow-xl shadow-green-900/20">
                    SIMPAN PEMBARUAN
                </button>
            </form>
        </div>
    </div>
</body>
</html>