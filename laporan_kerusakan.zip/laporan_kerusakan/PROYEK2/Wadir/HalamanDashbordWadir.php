<?php
session_start();
include '../config/Koneksi.php';

// 1. Proteksi Halaman
if(!isset($_SESSION['login']) || $_SESSION['role'] !== 'wadir'){
    header("Location: ../login/HalamanLogin.php");
    exit;
}

// 2. Ambil Statistik (PASTIKAN TAG PHP TIDAK TERPUTUS)
$total_laporan = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM laporan"));
$butuh_disposisi = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM laporan WHERE arahan_wadir IS NULL OR arahan_wadir = ''"));
$telah_disetujui = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM laporan WHERE arahan_wadir IS NOT NULL AND arahan_wadir != ''"));
$urgent = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM laporan WHERE jenis_kerusakan = 'URGENT'"));

// 3. Ambil Data untuk Tabel
$query_tabel = mysqli_query($koneksi, "SELECT * FROM laporan ORDER BY id_laporan DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Wadir - SarpraCare</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-50 min-h-screen flex">
    <aside class="w-64 bg-green-900 text-white p-6 sticky top-0 h-screen">
        <h1 class="text-xl font-bold mb-10">Sarpra<span class="text-yellow-400">Care</span></h1>
        <nav class="space-y-4">
            <a href="#" class="block p-3 bg-white/10 rounded-xl border-l-4 border-yellow-400">Dashboard</a>
            <a href="../login/HalamanLogin.php" class="block p-3 text-red-300">Keluar</a>
        </nav>
    </aside>

    <main class="flex-1 p-10">
        <header class="mb-10">
            <h1 class="text-2xl font-bold">Monitoring Fasilitas</h1>
            <p class="text-gray-500 text-sm">Halo, <span class="font-bold text-green-700"><?= $_SESSION['nama_pegawai']; ?></span></p>
        </header>

        <div class="grid grid-cols-4 gap-6 mb-10 text-center">
            <div class="bg-white p-6 rounded-3xl shadow-sm italic">Total: <?= $total_laporan; ?></div>
            <div class="bg-white p-6 rounded-3xl shadow-sm text-yellow-600">Butuh Arahan: <?= $butuh_disposisi; ?></div>
            <div class="bg-white p-6 rounded-3xl shadow-sm text-green-600">Selesai: <?= $telah_disetujui; ?></div>
            <div class="bg-white p-6 rounded-3xl shadow-sm text-red-600">Urgent: <?= $urgent; ?></div>
        </div>

        <div class="bg-white rounded-[32px] shadow-sm overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-gray-50 text-xs font-bold text-gray-400 uppercase">
                    <tr>
                        <th class="p-6">ID & Pelapor</th>
                        <th class="p-6">Fasilitas</th>
                        <th class="p-6">Status Arahan</th>
                        <th class="p-6">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php while($row = mysqli_fetch_assoc($query_tabel)): ?>
                    <tr>
                        <td class="p-6">#<?= $row['id_laporan']; ?> <br> <span class="text-[10px] text-gray-400"><?= $row['nim']; ?></span></td>
                        <td class="p-6 font-semibold"><?= $row['jenis_kerusakan']; ?></td>
                        <td class="p-6">
                            <?= empty($row['arahan_wadir']) ? '<span class="text-yellow-600">BELUM</span>' : '<span class="text-green-600">SUDAH</span>'; ?>
                        </td>
                        <td class="p-6">
                            <a href="DetailLaporanWadir.php?id=<?= $row['id_laporan']; ?>" class="bg-green-900 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md">Beri Arahan</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>