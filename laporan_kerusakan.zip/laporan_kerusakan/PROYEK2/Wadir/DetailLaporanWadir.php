<?php
session_start();
include '../config/Koneksi.php';

// 1. Proteksi Halaman
if(!isset($_SESSION['login']) || $_SESSION['role'] != 'wadir'){
    header("Location: ../login/HalamanLogin.php");
    exit;
}

// 2. Ambil ID dari URL
$id = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM laporan WHERE id_laporan = '$id'");
$data = mysqli_fetch_assoc($query);

// 3. Proses Simpan Arahan
if(isset($_POST['kirim_arahan'])) {
    $arahan = mysqli_real_escape_string($koneksi, $_POST['arahan']);
    
    $update = mysqli_query($koneksi, "UPDATE laporan SET arahan_wadir = '$arahan' WHERE id_laporan = '$id'");
    
    if($update) {
        echo "<script>alert('Arahan berhasil diteruskan ke Staf!'); window.location='HalamanDashbordWadir.php';</script>";
    } else {
        echo "Gagal: " . mysqli_error($koneksi);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Beri Arahan - SarpraCare</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-50 min-h-screen p-6 md:p-12">
    <div class="max-w-3xl mx-auto bg-white rounded-[40px] shadow-xl overflow-hidden border border-gray-100">
        <div class="bg-green-900 p-8 text-white">
            <h2 class="text-2xl font-bold">Disposisi Laporan #<?= $data['id_laporan']; ?></h2>
            <p class="text-green-200 text-sm">Berikan instruksi kerja untuk staf administrasi.</p>
        </div>

        <div class="p-8">
            <div class="grid grid-cols-2 gap-6 mb-8 bg-gray-50 p-6 rounded-3xl border border-dashed border-gray-200">
                <div>
                    <p class="text-[10px] font-bold text-gray-400 uppercase">Pelapor (Mahasiswa)</p>
                    <p class="text-sm font-bold text-gray-800"><?= $data['nim']; ?> - <?= $data['Jurusan']; ?></p>
                </div>
                <div>
                    <p class="text-[10px] font-bold text-gray-400 uppercase">Lokasi Fasilitas</p>
                    <p class="text-sm font-bold text-gray-800"><?= $data['lokasi_gedung']; ?>, Lt.<?= $data['Lantai']; ?> (<?= $data['lokasi_ruang']; ?>)</p>
                </div>
                <div class="col-span-2">
                    <p class="text-[10px] font-bold text-gray-400 uppercase">Deskripsi Kerusakan</p>
                    <p class="text-sm text-gray-700"><?= $data['deskripsi']; ?></p>
                </div>
            </div>

            <form method="POST" class="space-y-6">
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-2">Instruksi / Arahan Wadir 2</label>
                    <textarea name="arahan" required 
                        class="w-full p-5 bg-yellow-50 border-2 border-yellow-100 rounded-3xl outline-none focus:border-yellow-400 text-gray-800 placeholder-yellow-600/50" 
                        rows="5" 
                        placeholder="Contoh: Tolong staf segera cek ketersediaan suku cadang dan hubungi teknisi terkait..."><?= $data['arahan_wadir']; ?></textarea>
                </div>

                <div class="flex gap-4">
                    <button type="submit" name="kirim_arahan" class="flex-1 bg-green-800 text-white font-bold py-4 rounded-2xl hover:bg-green-900 transition shadow-lg">
                        <i class="fas fa-paper-plane mr-2"></i> KIRIM ARAHAN
                    </button>
                    <a href="HalamanDashbordWadir.php" class="flex-1 bg-gray-100 text-gray-500 font-bold py-4 rounded-2xl text-center hover:bg-gray-200 transition">
                        KEMBALI
                    </a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>